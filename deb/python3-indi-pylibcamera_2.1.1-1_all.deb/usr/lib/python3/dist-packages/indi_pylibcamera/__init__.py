"""
INDI driver for libcamera supported cameras
"""

__version__ = "2.1.1"
